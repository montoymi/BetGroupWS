create function xx_create_betgroup(p_nombre_polla character varying, p_private_flag integer, p_password_polla character varying, p_costo_flag integer, p_costo integer, p_admin_user_id integer, p_polla_template_id integer, OUT r_out_status_code character varying)
  returns character varying
language plpgsql
as $$
DECLARE
  lv_exists character varying(1) := 'N';
  l_polla_header_id INTEGER;
  l_polla_participant_id INTEGER;
BEGIN              
/*
    Validaciones:
       Validar que el admin sea un usuario correcto. Error code E0001
       Validar que la polla_template_id exista. Error code E0002
       Validar que si se indicó costo_flag = 0 entonces costo tiene que ser cero. Error Code E0003
       Validar que el costo no sea negativo. Error Code E0004
*/

IF p_admin_user_id IS NULL THEN
  r_out_status_code := 'E0001';
END IF;

BEGIN
  SELECT 'Y'
  INTO lv_exists
  FROM users
  where user_id = p_admin_user_id;
EXCEPTION when no_data_found then
  r_out_status_code := 'E0001';
END;

IF p_polla_template_id IS NULL THEN
  r_out_status_code := 'E0002';
END IF;

BEGIN
  SELECT 'Y'
  INTO lv_exists
  FROM template_headers
  where id = p_polla_template_id;
EXCEPTION when no_data_found then
  r_out_status_code := 'E0002';
END;

IF p_costo_flag = '0' AND p_costo > 0 THEN
  r_out_status_code := 'E0003';
END IF;

IF p_costo < 0 THEN
  r_out_status_code := 'E0004';
END IF;

insert into polla_headers
(
  polla_name,
  template_header_id,
  admin_user_id,
  credit_amount,
  access_flag,
  status,
  password,
  cost_flag) 
values 
  (
  p_nombre_polla,
  p_template_header_id,
  p_admin_user_id,
  p_costo,
  p_private_flag,
  '1',
  p_password_polla,
  p_costo_flag) RETURNING ID into l_polla_header_id;

  if p_costo > 0 then 
    insert into credit_transactions(transaction_type_id,
                                    transaction_date,
                                    credit_amount,
                                    status,
                                    comments,
                                    user_id,
                                    created_by,
                                    creation_date,
                                    last_updated_by,
                                    last_updated_date) VALUES 
                                    (4,
                                    now(),
                                    p_costo,
                                    '1',
                                    'Inscripcion al juego '||p_polla_name,
                                    p_admin_user_id,
                                    p_admin_user_id,
                                    now(),
                                    p_admin_user_id,
                                    now());
  end if;
  
  insert into polla_participants (polla_header_id,
  user_id,
  inscription_date,
  admin_payment_status,
  total,
  earnings,
  position,
  status) values 
  (l_polla_header_id,
  p_admin_user_id,
  sysdate,
  '0',
  0,
  0,
  null,
  '1') returning ID into l_polla_participant_id;
  
  insert into polla_matches (polla_header_id,match_id)
  select l_polla_header_id,match_id
  from template_details
  where template_header_id = p_polla_template_id;

  insert into polla_bets (polla_match_id,
                          polla_participant_id)
  select id,l_polla_participant_id
  from polla_matches
  where polla_header_id = l_polla_header_id;
  
  r_out_status_code := '';

END;
$$;

