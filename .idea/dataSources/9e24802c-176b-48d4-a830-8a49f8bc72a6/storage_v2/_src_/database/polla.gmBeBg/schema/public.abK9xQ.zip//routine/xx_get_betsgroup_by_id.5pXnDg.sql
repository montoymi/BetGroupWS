create function xx_get_betsgroup_by_id(p_betsgroup_id integer)
  returns TABLE(r_category_id integer, r_tournament_id integer, r_phase_id integer, r_group_id integer, r_match_id integer, r_bet_level integer, r_betsgroup_name character varying, r_administrator_id integer, r_enabled_flag character varying, r_access_flag character varying)
language plpgsql
as $$
BEGIN
     RETURN QUERY
select th.sports_id as category_id,
       th.id as tournament_id, --En este caso ya no seria el torneo en si sino mas bien el template cabecera
       null::integer phase_id,
       null::integer group_id,
       null::integer match_id,
       1::integer bet_level, --Tenemos que conversar este tema porque el esquema ya no es el mismo, campos a discutir phase_id,group_id y match_id
       polla_name::character varying AS betsgroup_name,
       b.admin_user_id as administrator_id,
       b.status enabled_flag,
       b.access_flag --nuevo campo para saber si la polla es publica o privada
from polla_headers as b,
     template_headers th
where b.id = p_betsgroup_id
  and b.template_header_id = th.id;
END;
$$;

