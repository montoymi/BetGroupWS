create view pol_matches_v as
  SELECT t.sport_id AS category_id,
    t.id AS tournament_id,
    p.id AS phase_id,
    g.id AS group_id,
    g.group_code,
    g.group_name,
    m.local_team_id AS local_id,
    tl.team_name AS local_team_name,
    tl.image AS image_local,
    m.visitor_team_id,
    tv.team_name AS visitor_team_name,
    tv.image AS image_visitor,
    m.local_score AS score_local,
    m.visitor_score AS score_visitor,
    m.result_match,
    m.match_date,
    m.match_place,
        CASE m.status
            WHEN 1 THEN 'Y'::text
            ELSE 'N'::text
        END AS enabled_flag
   FROM matchs m,
    teams tl,
    teams tv,
    groups g,
    phases p,
    tournaments t
  WHERE (((((m.local_team_id = tl.id) AND (m.visitor_team_id = tv.id)) AND (m.group_id = g.id)) AND (g.phase_id = p.id)) AND (p.tournament_id = t.id));

