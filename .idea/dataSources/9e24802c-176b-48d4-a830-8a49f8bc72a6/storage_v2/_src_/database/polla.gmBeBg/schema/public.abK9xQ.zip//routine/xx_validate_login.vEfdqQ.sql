create function xx_validate_login(p_nickname character varying, p_password character varying, OUT r_validate_access character varying)
  returns character varying
language plpgsql
as $$
DECLARE
    p_nickname ALIAS FOR $1;
    p_password ALIAS FOR $2;
    l_access character varying;
BEGIN                         
    SELECT 'Y'
    INTO r_validate_access
    FROM users
    WHERE upper(nickname) = upper(P_nickname)
      AND user_password = md5(p_password);
    if r_validate_access is null then
      r_validate_access := 'N';
    else
      update users
      set last_login_date = now(),
          count_login = CASE when count_login is null then
              '1'
            else
              count_login + 1
            end
      where upper(nickname) = upper(P_nickname);
    end if;
    l_access := r_validate_access;
END;
$$;

