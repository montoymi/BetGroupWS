create function xx_get_betgroupplayer_by_player(p_betgroup_id integer, p_user_id integer, OUT r_betsgroup_player_id integer, OUT r_total integer, OUT r_admin_payment_status integer, OUT r_enabled_flag character varying, OUT r_earnings double precision)
  returns SETOF record
language sql
as $$
select  pp.id,
	pp.total,
	pp.admin_payment_status,
	pp.enabled_flag,
	pp.earnings       
from polla_participants pp
where pp.polla_header_id = $1
  and pp.user_id = $2;
$$;

