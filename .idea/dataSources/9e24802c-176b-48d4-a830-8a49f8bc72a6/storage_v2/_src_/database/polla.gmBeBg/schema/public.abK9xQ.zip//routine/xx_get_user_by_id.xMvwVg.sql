create function xx_get_user_by_id(p_user_id integer, OUT r_email_address character varying, OUT r_full_name character varying, OUT r_nickname character varying, OUT r_referred_user_id integer, OUT r_country_code character varying, OUT r_sex character varying, OUT r_date_of_birth date, OUT r_preferred_language character varying, OUT r_status integer, OUT r_enabled_flag character varying)
  returns SETOF record
language sql
as $$
select  u.email_address,
	u.full_name,
	u.nickname,
	u.referred_user_id,
	u.country_code,
	u.sex,
	u.date_of_birth,
	u.preferred_language,
        u.status,        
        u.enabled_flag        
from users u
where u.user_id = $1;
$$;

