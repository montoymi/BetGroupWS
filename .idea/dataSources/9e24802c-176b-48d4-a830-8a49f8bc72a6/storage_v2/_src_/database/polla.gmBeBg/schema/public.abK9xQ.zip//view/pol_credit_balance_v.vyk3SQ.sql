create view pol_credit_balance_v as
  SELECT ct.user_id,
    sum((ct.credit_amount *
        CASE
            WHEN (ctt.transaction_sign = '+'::bpchar) THEN 1
            ELSE (-1)
        END)) AS credit_amount
   FROM credit_transactions ct,
    credit_transaction_types ctt
  WHERE ((ct.transaction_type_id = ctt.id) AND (ct.status = 1))
  GROUP BY ct.user_id;

