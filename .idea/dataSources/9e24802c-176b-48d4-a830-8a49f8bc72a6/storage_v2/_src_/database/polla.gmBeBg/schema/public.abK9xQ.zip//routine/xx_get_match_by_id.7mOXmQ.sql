create function xx_get_match_by_id(p_match_id integer, OUT r_category_id integer, OUT r_tournament_id integer, OUT r_phase_id integer, OUT r_group_id integer, OUT r_group_code character varying, OUT r_group_name character varying, OUT r_local_id integer, OUT r_local_team_name character varying, OUT r_image_local character varying, OUT r_visitor_id integer, OUT r_visitor_team_name character varying, OUT r_image_visitor character varying, OUT r_score_local integer, OUT r_score_visitor integer, OUT r_result_match character varying, OUT r_match_date timestamp without time zone, OUT r_match_place character varying, OUT r_enabled_flag character varying)
  returns SETOF record
language sql
as $$
select t.sport_id category_id,
       t.id as tournament_id,
       p.id phase_id,
       g.id group_id,
       g.group_code,
       g.group_name,
       m.local_team_id local_id,
       tl.team_name as local_team_name,
       tl.image as image_local,
       m.visitor_team_id,
       tv.team_name as visitor_team_name,
       tv.image as image_visitor,
       m.local_score score_local,
       m.visitor_score score_visitor,
       m.result_match,	
       m.match_date,
       m.match_place,
       CASE m.status WHEN 1 THEN 'Y' ELSE 'N' END enabled_flag
from matchs as m,
     teams as tl,
     teams as tv,
     groups as g,
     phases as p,
     tournaments as t
where m.local_team_id = tl.id
  and m.visitor_team_id = tv.id
  and m.group_id = g.id
  and g.phase_id = p.id
  and p.tournament_id = t.id
  and m.id = $1;
$$;

