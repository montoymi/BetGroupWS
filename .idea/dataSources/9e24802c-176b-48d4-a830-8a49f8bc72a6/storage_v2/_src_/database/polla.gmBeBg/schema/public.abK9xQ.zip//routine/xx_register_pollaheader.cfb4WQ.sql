create function xx_register_pollaheader(p_polla_header_id integer, p_user_id integer)
  returns character varying
language plpgsql
as $$
DECLARE
  l_cost integer;
  l_polla_name character varying(100);
  lv_exists character varying(1) := 'N';
  l_polla_participant_id integer;
BEGIN
  
  /*Validar que el usuario exista.      E0001
  Validar que la polla header exista.   E0005*/
  BEGIN
  SELECT 'Y'
  INTO lv_exists
  FROM users
  where user_id = p_user_id;
EXCEPTION when no_data_found then
  RETURN 'E0001';
END;

BEGIN
  SELECT 'Y'
  INTO lv_exists
  FROM template_headers
  where id = p_polla_header_id;
EXCEPTION when no_data_found then
  RETURN 'E0002';
END;

BEGIN
  SELECT polla_name,credit_amount
  INTO l_polla_name,l_cost
  FROM polla_headers
  WHERE polla_header_id = p_polla_header_id;
EXCEPTION when no_data_found then
  RETURN 'E0005';
END;

  if l_cost > 0 then 
    insert into credit_transactions(transaction_type_id,
                                    transaction_date,
                                    credit_amount,
                                    status,
                                    comments,
                                    user_id,
                                    created_by,
                                    creation_date,
                                    last_updated_by,
                                    last_updated_date) VALUES 
                                    (4,
                                    now(),
                                    l_cost,
                                    '1',
                                    'Inscripcion al juego '||l_polla_name,
                                    p_user_id,
                                    p_user_id,
                                    now(),
                                    p_user_id,
                                    now());
  end if;
  
  insert into polla_participants (polla_header_id,
  user_id,
  inscription_date,
  admin_payment_status,
  total,
  earnings,
  position,
  status) values 
  (p_polla_header_id,
  p_user_id,
  sysdate,
  '0',
  0,
  0,
  null,
  '1') returning ID into l_polla_participant_id;
  
  insert into polla_bets (polla_match_id,
                          polla_participant_id)
  select id,l_polla_participant_id
  from polla_matches
  where polla_header_id = p_polla_header_id;
  
  return '';
END;
$$;

